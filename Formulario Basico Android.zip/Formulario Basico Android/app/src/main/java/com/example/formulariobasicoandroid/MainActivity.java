package com.example.formulariobasicoandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    Button btnListo;
    EditText txtNombre, txtApellido, txtCedula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnListo = (Button) findViewById (R.id.btnListo);
        txtNombre = (EditText) findViewById(R.id.txtNombre);
        txtApellido = (EditText) findViewById(R.id.txtApellido);
        txtCedula = (EditText) findViewById(R.id.txtCedula);

        btnListo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Registrado", Toast.LENGTH_SHORT).show();
                borrar();
            }

        });
            }

            private void borrar(){
                txtNombre.setText("");
                txtApellido.setText("");
                txtCedula.setText("");
            }
        }
